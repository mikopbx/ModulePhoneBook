<?php
return [
    'module_phnbk_Disconnected' => 'Modul deaktiviert',
    'module_phnbk_Connected' => 'Modul angeschlossen',
    'module_phnbk_AlreadyExistWithThisNumber' => 'Eintrag mit der Nummer% repesent% existiert bereits',
    'module_phnbk_AddNewRecord' => 'Neuen Eintrag hinzufügen',
    'module_phnbk_ColumnNumber' => 'Telefon',
    'module_phnbk_ColumnName' => 'Name des Abonnenten',
    'SubHeaderModulePhoneBook' => 'Ermöglicht die Anzeige der Namen von Anrufern während eines Anrufs und im Gesprächsverlauf',
    'BreadcrumbModulePhoneBook' => 'Telefonbuch',
    'mo_ModuleModulePhoneBook' => 'Telefonbuchmodul',
    /**
 * Copyright (C) MIKO LLC - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Nikolay Beketov, 6 2018
 *
 */
    'repModulePhoneBook' => 'Telefonbuchmodul -% repesent%',
];
